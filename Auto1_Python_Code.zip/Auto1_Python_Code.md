

```python
# Loading Libraries 

import numpy as np
import pandas as pd
import scipy 
import matplotlib.pyplot as plt
import sklearn as sk
import seaborn as sns
```


```python
# Laod the dataset name Auto1
Auto1 = pd.read_csv("C:/Users/HP/Downloads/Auto1-DS-TestData.csv")
```


```python
# observations of dimensions of the dataset rows & columns
Auto1.shape
```




    (205, 26)




```python
# observations of columns 
Auto1.columns
```




    Index(['symboling', 'normalized-losses', 'make', 'fuel-type', 'aspiration',
           'num-of-doors', 'body-style', 'drive-wheels', 'engine-location',
           'wheel-base', 'length', 'width', 'height', 'curb-weight', 'engine-type',
           'num-of-cylinders', 'engine-size', 'fuel-system', 'bore', 'stroke',
           'compression-ratio', 'horsepower', 'peak-rpm', 'city-mpg',
           'highway-mpg', 'price'],
          dtype='object')




```python
# observations of Daata frames
Auto1.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 205 entries, 0 to 204
    Data columns (total 26 columns):
    symboling            205 non-null int64
    normalized-losses    205 non-null object
    make                 205 non-null object
    fuel-type            205 non-null object
    aspiration           205 non-null object
    num-of-doors         205 non-null object
    body-style           205 non-null object
    drive-wheels         205 non-null object
    engine-location      205 non-null object
    wheel-base           205 non-null float64
    length               205 non-null float64
    width                205 non-null float64
    height               205 non-null float64
    curb-weight          205 non-null int64
    engine-type          205 non-null object
    num-of-cylinders     205 non-null object
    engine-size          205 non-null int64
    fuel-system          205 non-null object
    bore                 205 non-null object
    stroke               205 non-null object
    compression-ratio    205 non-null float64
    horsepower           205 non-null object
    peak-rpm             205 non-null object
    city-mpg             205 non-null int64
    highway-mpg          205 non-null int64
    price                205 non-null object
    dtypes: float64(5), int64(5), object(16)
    memory usage: 41.7+ KB
    


```python
# identifying the Duplicates if any
Auto1.duplicated(subset=None, keep='first')
```




    0      False
    1      False
    2      False
    3      False
    4      False
    5      False
    6      False
    7      False
    8      False
    9      False
    10     False
    11     False
    12     False
    13     False
    14     False
    15     False
    16     False
    17     False
    18     False
    19     False
    20     False
    21     False
    22     False
    23     False
    24     False
    25     False
    26     False
    27     False
    28     False
    29     False
           ...  
    175    False
    176    False
    177    False
    178    False
    179    False
    180    False
    181    False
    182    False
    183    False
    184    False
    185    False
    186    False
    187    False
    188    False
    189    False
    190    False
    191    False
    192    False
    193    False
    194    False
    195    False
    196    False
    197    False
    198    False
    199    False
    200    False
    201    False
    202    False
    203    False
    204    False
    Length: 205, dtype: bool




```python
# imputation and replacing the missing values
from sklearn.preprocessing import Imputer
Auto1 = Auto1.replace('?', 'NaN')
imp = Imputer(missing_values='NaN', strategy='mean' )
Auto1[['normalized-losses','bore','stroke','horsepower','peak-rpm','price']] = imp.fit_transform(Auto1[['normalized-losses','bore','stroke','horsepower','peak-rpm','price']])
Auto1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>symboling</th>
      <th>normalized-losses</th>
      <th>make</th>
      <th>fuel-type</th>
      <th>aspiration</th>
      <th>num-of-doors</th>
      <th>body-style</th>
      <th>drive-wheels</th>
      <th>engine-location</th>
      <th>wheel-base</th>
      <th>...</th>
      <th>engine-size</th>
      <th>fuel-system</th>
      <th>bore</th>
      <th>stroke</th>
      <th>compression-ratio</th>
      <th>horsepower</th>
      <th>peak-rpm</th>
      <th>city-mpg</th>
      <th>highway-mpg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3</td>
      <td>122.0</td>
      <td>alfa-romero</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>front</td>
      <td>88.6</td>
      <td>...</td>
      <td>130</td>
      <td>mpfi</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111.0</td>
      <td>5000.0</td>
      <td>21</td>
      <td>27</td>
      <td>13495.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>122.0</td>
      <td>alfa-romero</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>front</td>
      <td>88.6</td>
      <td>...</td>
      <td>130</td>
      <td>mpfi</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111.0</td>
      <td>5000.0</td>
      <td>21</td>
      <td>27</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>122.0</td>
      <td>alfa-romero</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>hatchback</td>
      <td>rwd</td>
      <td>front</td>
      <td>94.5</td>
      <td>...</td>
      <td>152</td>
      <td>mpfi</td>
      <td>2.68</td>
      <td>3.47</td>
      <td>9.0</td>
      <td>154.0</td>
      <td>5000.0</td>
      <td>19</td>
      <td>26</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>164.0</td>
      <td>audi</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>front</td>
      <td>99.8</td>
      <td>...</td>
      <td>109</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>10.0</td>
      <td>102.0</td>
      <td>5500.0</td>
      <td>24</td>
      <td>30</td>
      <td>13950.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>164.0</td>
      <td>audi</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>4wd</td>
      <td>front</td>
      <td>99.4</td>
      <td>...</td>
      <td>136</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>8.0</td>
      <td>115.0</td>
      <td>5500.0</td>
      <td>18</td>
      <td>22</td>
      <td>17450.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 26 columns</p>
</div>




```python
Auto1.make.value_counts().nlargest(10).plot(kind='bar', figsize=(15,5))
plt.title("No of vehicles by Brand")
plt.ylabel('No of vehicles')
plt.xlabel('Brand');
```


![png](output_7_0.png)



```python
Auto1['fuel-type'].value_counts().plot(kind='bar',color='green')
plt.title("Frequence Vs Type of Fuel")
plt.ylabel('No of vehicles')
plt.xlabel('Type of fuel');
```


![png](output_8_0.png)



```python
# Histogram Figures 

%matplotlib inline
Auto1.hist(bins=30, figsize=(30,15))
plt.savefig("Histogram Figures")
plt.show()
```


![png](output_9_0.png)



```python
# observation of string data missing
Auto1.groupby('num-of-doors').size()

```




    num-of-doors
    NaN       2
    four    114
    two      89
    dtype: int64




```python
# replacing the missing values for variable num-of-doors
Auto1 = Auto1.replace("NaN","four")
Auto1.head(35) #for 29 row/observation num-of-doors data is missing so considered till 35 observations
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>symboling</th>
      <th>normalized-losses</th>
      <th>make</th>
      <th>fuel-type</th>
      <th>aspiration</th>
      <th>num-of-doors</th>
      <th>body-style</th>
      <th>drive-wheels</th>
      <th>engine-location</th>
      <th>wheel-base</th>
      <th>...</th>
      <th>engine-size</th>
      <th>fuel-system</th>
      <th>bore</th>
      <th>stroke</th>
      <th>compression-ratio</th>
      <th>horsepower</th>
      <th>peak-rpm</th>
      <th>city-mpg</th>
      <th>highway-mpg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3</td>
      <td>122.0</td>
      <td>alfa-romero</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>front</td>
      <td>88.6</td>
      <td>...</td>
      <td>130</td>
      <td>mpfi</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.00</td>
      <td>111.0</td>
      <td>5000.0</td>
      <td>21</td>
      <td>27</td>
      <td>13495.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>122.0</td>
      <td>alfa-romero</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>convertible</td>
      <td>rwd</td>
      <td>front</td>
      <td>88.6</td>
      <td>...</td>
      <td>130</td>
      <td>mpfi</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.00</td>
      <td>111.0</td>
      <td>5000.0</td>
      <td>21</td>
      <td>27</td>
      <td>16500.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>122.0</td>
      <td>alfa-romero</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>hatchback</td>
      <td>rwd</td>
      <td>front</td>
      <td>94.5</td>
      <td>...</td>
      <td>152</td>
      <td>mpfi</td>
      <td>2.68</td>
      <td>3.47</td>
      <td>9.00</td>
      <td>154.0</td>
      <td>5000.0</td>
      <td>19</td>
      <td>26</td>
      <td>16500.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>164.0</td>
      <td>audi</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>front</td>
      <td>99.8</td>
      <td>...</td>
      <td>109</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>10.00</td>
      <td>102.0</td>
      <td>5500.0</td>
      <td>24</td>
      <td>30</td>
      <td>13950.000000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>164.0</td>
      <td>audi</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>4wd</td>
      <td>front</td>
      <td>99.4</td>
      <td>...</td>
      <td>136</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>8.00</td>
      <td>115.0</td>
      <td>5500.0</td>
      <td>18</td>
      <td>22</td>
      <td>17450.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2</td>
      <td>122.0</td>
      <td>audi</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>front</td>
      <td>99.8</td>
      <td>...</td>
      <td>136</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>8.50</td>
      <td>110.0</td>
      <td>5500.0</td>
      <td>19</td>
      <td>25</td>
      <td>15250.000000</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1</td>
      <td>158.0</td>
      <td>audi</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>front</td>
      <td>105.8</td>
      <td>...</td>
      <td>136</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>8.50</td>
      <td>110.0</td>
      <td>5500.0</td>
      <td>19</td>
      <td>25</td>
      <td>17710.000000</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1</td>
      <td>122.0</td>
      <td>audi</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>wagon</td>
      <td>fwd</td>
      <td>front</td>
      <td>105.8</td>
      <td>...</td>
      <td>136</td>
      <td>mpfi</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>8.50</td>
      <td>110.0</td>
      <td>5500.0</td>
      <td>19</td>
      <td>25</td>
      <td>18920.000000</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1</td>
      <td>158.0</td>
      <td>audi</td>
      <td>gas</td>
      <td>turbo</td>
      <td>four</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>front</td>
      <td>105.8</td>
      <td>...</td>
      <td>131</td>
      <td>mpfi</td>
      <td>3.13</td>
      <td>3.40</td>
      <td>8.30</td>
      <td>140.0</td>
      <td>5500.0</td>
      <td>17</td>
      <td>20</td>
      <td>23875.000000</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0</td>
      <td>122.0</td>
      <td>audi</td>
      <td>gas</td>
      <td>turbo</td>
      <td>two</td>
      <td>hatchback</td>
      <td>4wd</td>
      <td>front</td>
      <td>99.5</td>
      <td>...</td>
      <td>131</td>
      <td>mpfi</td>
      <td>3.13</td>
      <td>3.40</td>
      <td>7.00</td>
      <td>160.0</td>
      <td>5500.0</td>
      <td>16</td>
      <td>22</td>
      <td>13207.129353</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2</td>
      <td>192.0</td>
      <td>bmw</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>101.2</td>
      <td>...</td>
      <td>108</td>
      <td>mpfi</td>
      <td>3.50</td>
      <td>2.80</td>
      <td>8.80</td>
      <td>101.0</td>
      <td>5800.0</td>
      <td>23</td>
      <td>29</td>
      <td>16430.000000</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0</td>
      <td>192.0</td>
      <td>bmw</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>101.2</td>
      <td>...</td>
      <td>108</td>
      <td>mpfi</td>
      <td>3.50</td>
      <td>2.80</td>
      <td>8.80</td>
      <td>101.0</td>
      <td>5800.0</td>
      <td>23</td>
      <td>29</td>
      <td>16925.000000</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0</td>
      <td>188.0</td>
      <td>bmw</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>101.2</td>
      <td>...</td>
      <td>164</td>
      <td>mpfi</td>
      <td>3.31</td>
      <td>3.19</td>
      <td>9.00</td>
      <td>121.0</td>
      <td>4250.0</td>
      <td>21</td>
      <td>28</td>
      <td>20970.000000</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0</td>
      <td>188.0</td>
      <td>bmw</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>101.2</td>
      <td>...</td>
      <td>164</td>
      <td>mpfi</td>
      <td>3.31</td>
      <td>3.19</td>
      <td>9.00</td>
      <td>121.0</td>
      <td>4250.0</td>
      <td>21</td>
      <td>28</td>
      <td>21105.000000</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1</td>
      <td>122.0</td>
      <td>bmw</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>103.5</td>
      <td>...</td>
      <td>164</td>
      <td>mpfi</td>
      <td>3.31</td>
      <td>3.19</td>
      <td>9.00</td>
      <td>121.0</td>
      <td>4250.0</td>
      <td>20</td>
      <td>25</td>
      <td>24565.000000</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0</td>
      <td>122.0</td>
      <td>bmw</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>103.5</td>
      <td>...</td>
      <td>209</td>
      <td>mpfi</td>
      <td>3.62</td>
      <td>3.39</td>
      <td>8.00</td>
      <td>182.0</td>
      <td>5400.0</td>
      <td>16</td>
      <td>22</td>
      <td>30760.000000</td>
    </tr>
    <tr>
      <th>16</th>
      <td>0</td>
      <td>122.0</td>
      <td>bmw</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>103.5</td>
      <td>...</td>
      <td>209</td>
      <td>mpfi</td>
      <td>3.62</td>
      <td>3.39</td>
      <td>8.00</td>
      <td>182.0</td>
      <td>5400.0</td>
      <td>16</td>
      <td>22</td>
      <td>41315.000000</td>
    </tr>
    <tr>
      <th>17</th>
      <td>0</td>
      <td>122.0</td>
      <td>bmw</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>rwd</td>
      <td>front</td>
      <td>110.0</td>
      <td>...</td>
      <td>209</td>
      <td>mpfi</td>
      <td>3.62</td>
      <td>3.39</td>
      <td>8.00</td>
      <td>182.0</td>
      <td>5400.0</td>
      <td>15</td>
      <td>20</td>
      <td>36880.000000</td>
    </tr>
    <tr>
      <th>18</th>
      <td>2</td>
      <td>121.0</td>
      <td>chevrolet</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>front</td>
      <td>88.4</td>
      <td>...</td>
      <td>61</td>
      <td>2bbl</td>
      <td>2.91</td>
      <td>3.03</td>
      <td>9.50</td>
      <td>48.0</td>
      <td>5100.0</td>
      <td>47</td>
      <td>53</td>
      <td>5151.000000</td>
    </tr>
    <tr>
      <th>19</th>
      <td>1</td>
      <td>98.0</td>
      <td>chevrolet</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>front</td>
      <td>94.5</td>
      <td>...</td>
      <td>90</td>
      <td>2bbl</td>
      <td>3.03</td>
      <td>3.11</td>
      <td>9.60</td>
      <td>70.0</td>
      <td>5400.0</td>
      <td>38</td>
      <td>43</td>
      <td>6295.000000</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0</td>
      <td>81.0</td>
      <td>chevrolet</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>front</td>
      <td>94.5</td>
      <td>...</td>
      <td>90</td>
      <td>2bbl</td>
      <td>3.03</td>
      <td>3.11</td>
      <td>9.60</td>
      <td>70.0</td>
      <td>5400.0</td>
      <td>38</td>
      <td>43</td>
      <td>6575.000000</td>
    </tr>
    <tr>
      <th>21</th>
      <td>1</td>
      <td>118.0</td>
      <td>dodge</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>front</td>
      <td>93.7</td>
      <td>...</td>
      <td>90</td>
      <td>2bbl</td>
      <td>2.97</td>
      <td>3.23</td>
      <td>9.41</td>
      <td>68.0</td>
      <td>5500.0</td>
      <td>37</td>
      <td>41</td>
      <td>5572.000000</td>
    </tr>
    <tr>
      <th>22</th>
      <td>1</td>
      <td>118.0</td>
      <td>dodge</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>front</td>
      <td>93.7</td>
      <td>...</td>
      <td>90</td>
      <td>2bbl</td>
      <td>2.97</td>
      <td>3.23</td>
      <td>9.40</td>
      <td>68.0</td>
      <td>5500.0</td>
      <td>31</td>
      <td>38</td>
      <td>6377.000000</td>
    </tr>
    <tr>
      <th>23</th>
      <td>1</td>
      <td>118.0</td>
      <td>dodge</td>
      <td>gas</td>
      <td>turbo</td>
      <td>two</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>front</td>
      <td>93.7</td>
      <td>...</td>
      <td>98</td>
      <td>mpfi</td>
      <td>3.03</td>
      <td>3.39</td>
      <td>7.60</td>
      <td>102.0</td>
      <td>5500.0</td>
      <td>24</td>
      <td>30</td>
      <td>7957.000000</td>
    </tr>
    <tr>
      <th>24</th>
      <td>1</td>
      <td>148.0</td>
      <td>dodge</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>front</td>
      <td>93.7</td>
      <td>...</td>
      <td>90</td>
      <td>2bbl</td>
      <td>2.97</td>
      <td>3.23</td>
      <td>9.40</td>
      <td>68.0</td>
      <td>5500.0</td>
      <td>31</td>
      <td>38</td>
      <td>6229.000000</td>
    </tr>
    <tr>
      <th>25</th>
      <td>1</td>
      <td>148.0</td>
      <td>dodge</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>front</td>
      <td>93.7</td>
      <td>...</td>
      <td>90</td>
      <td>2bbl</td>
      <td>2.97</td>
      <td>3.23</td>
      <td>9.40</td>
      <td>68.0</td>
      <td>5500.0</td>
      <td>31</td>
      <td>38</td>
      <td>6692.000000</td>
    </tr>
    <tr>
      <th>26</th>
      <td>1</td>
      <td>148.0</td>
      <td>dodge</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>front</td>
      <td>93.7</td>
      <td>...</td>
      <td>90</td>
      <td>2bbl</td>
      <td>2.97</td>
      <td>3.23</td>
      <td>9.40</td>
      <td>68.0</td>
      <td>5500.0</td>
      <td>31</td>
      <td>38</td>
      <td>7609.000000</td>
    </tr>
    <tr>
      <th>27</th>
      <td>1</td>
      <td>148.0</td>
      <td>dodge</td>
      <td>gas</td>
      <td>turbo</td>
      <td>four</td>
      <td>sedan</td>
      <td>fwd</td>
      <td>front</td>
      <td>93.7</td>
      <td>...</td>
      <td>98</td>
      <td>mpfi</td>
      <td>3.03</td>
      <td>3.39</td>
      <td>7.60</td>
      <td>102.0</td>
      <td>5500.0</td>
      <td>24</td>
      <td>30</td>
      <td>8558.000000</td>
    </tr>
    <tr>
      <th>28</th>
      <td>-1</td>
      <td>110.0</td>
      <td>dodge</td>
      <td>gas</td>
      <td>std</td>
      <td>four</td>
      <td>wagon</td>
      <td>fwd</td>
      <td>front</td>
      <td>103.3</td>
      <td>...</td>
      <td>122</td>
      <td>2bbl</td>
      <td>3.34</td>
      <td>3.46</td>
      <td>8.50</td>
      <td>88.0</td>
      <td>5000.0</td>
      <td>24</td>
      <td>30</td>
      <td>8921.000000</td>
    </tr>
    <tr>
      <th>29</th>
      <td>3</td>
      <td>145.0</td>
      <td>dodge</td>
      <td>gas</td>
      <td>turbo</td>
      <td>two</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>front</td>
      <td>95.9</td>
      <td>...</td>
      <td>156</td>
      <td>mfi</td>
      <td>3.60</td>
      <td>3.90</td>
      <td>7.00</td>
      <td>145.0</td>
      <td>5000.0</td>
      <td>19</td>
      <td>24</td>
      <td>12964.000000</td>
    </tr>
    <tr>
      <th>30</th>
      <td>2</td>
      <td>137.0</td>
      <td>honda</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>front</td>
      <td>86.6</td>
      <td>...</td>
      <td>92</td>
      <td>1bbl</td>
      <td>2.91</td>
      <td>3.41</td>
      <td>9.60</td>
      <td>58.0</td>
      <td>4800.0</td>
      <td>49</td>
      <td>54</td>
      <td>6479.000000</td>
    </tr>
    <tr>
      <th>31</th>
      <td>2</td>
      <td>137.0</td>
      <td>honda</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>front</td>
      <td>86.6</td>
      <td>...</td>
      <td>92</td>
      <td>1bbl</td>
      <td>2.91</td>
      <td>3.41</td>
      <td>9.20</td>
      <td>76.0</td>
      <td>6000.0</td>
      <td>31</td>
      <td>38</td>
      <td>6855.000000</td>
    </tr>
    <tr>
      <th>32</th>
      <td>1</td>
      <td>101.0</td>
      <td>honda</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>front</td>
      <td>93.7</td>
      <td>...</td>
      <td>79</td>
      <td>1bbl</td>
      <td>2.91</td>
      <td>3.07</td>
      <td>10.10</td>
      <td>60.0</td>
      <td>5500.0</td>
      <td>38</td>
      <td>42</td>
      <td>5399.000000</td>
    </tr>
    <tr>
      <th>33</th>
      <td>1</td>
      <td>101.0</td>
      <td>honda</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>front</td>
      <td>93.7</td>
      <td>...</td>
      <td>92</td>
      <td>1bbl</td>
      <td>2.91</td>
      <td>3.41</td>
      <td>9.20</td>
      <td>76.0</td>
      <td>6000.0</td>
      <td>30</td>
      <td>34</td>
      <td>6529.000000</td>
    </tr>
    <tr>
      <th>34</th>
      <td>1</td>
      <td>101.0</td>
      <td>honda</td>
      <td>gas</td>
      <td>std</td>
      <td>two</td>
      <td>hatchback</td>
      <td>fwd</td>
      <td>front</td>
      <td>93.7</td>
      <td>...</td>
      <td>92</td>
      <td>1bbl</td>
      <td>2.91</td>
      <td>3.41</td>
      <td>9.20</td>
      <td>76.0</td>
      <td>6000.0</td>
      <td>30</td>
      <td>34</td>
      <td>7129.000000</td>
    </tr>
  </tbody>
</table>
<p>35 rows × 26 columns</p>
</div>




```python
# check of imputation and repacing for string variable 
Auto1.groupby('num-of-doors').size()
```




    num-of-doors
    four    116
    two      89
    dtype: int64




```python
from sklearn.preprocessing import OneHotEncoder, LabelEncoder
labelencoder = LabelEncoder()
for i in ['make','fuel-type','aspiration', 'num-of-doors','body-style','drive-wheels','engine-location','engine-type','num-of-cylinders','fuel-system']:
    Auto1[i] = labelencoder.fit_transform(Auto1[i])
Auto1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>symboling</th>
      <th>normalized-losses</th>
      <th>make</th>
      <th>fuel-type</th>
      <th>aspiration</th>
      <th>num-of-doors</th>
      <th>body-style</th>
      <th>drive-wheels</th>
      <th>engine-location</th>
      <th>wheel-base</th>
      <th>...</th>
      <th>engine-size</th>
      <th>fuel-system</th>
      <th>bore</th>
      <th>stroke</th>
      <th>compression-ratio</th>
      <th>horsepower</th>
      <th>peak-rpm</th>
      <th>city-mpg</th>
      <th>highway-mpg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3</td>
      <td>122.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>88.6</td>
      <td>...</td>
      <td>130</td>
      <td>5</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111.0</td>
      <td>5000.0</td>
      <td>21</td>
      <td>27</td>
      <td>13495.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>122.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>88.6</td>
      <td>...</td>
      <td>130</td>
      <td>5</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111.0</td>
      <td>5000.0</td>
      <td>21</td>
      <td>27</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>122.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>94.5</td>
      <td>...</td>
      <td>152</td>
      <td>5</td>
      <td>2.68</td>
      <td>3.47</td>
      <td>9.0</td>
      <td>154.0</td>
      <td>5000.0</td>
      <td>19</td>
      <td>26</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>164.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>99.8</td>
      <td>...</td>
      <td>109</td>
      <td>5</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>10.0</td>
      <td>102.0</td>
      <td>5500.0</td>
      <td>24</td>
      <td>30</td>
      <td>13950.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>164.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>99.4</td>
      <td>...</td>
      <td>136</td>
      <td>5</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>8.0</td>
      <td>115.0</td>
      <td>5500.0</td>
      <td>18</td>
      <td>22</td>
      <td>17450.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 26 columns</p>
</div>




```python
# Descriptive Statistics (Basic understanding of significant variables 
Auto1.describe().round(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>symboling</th>
      <th>normalized-losses</th>
      <th>make</th>
      <th>fuel-type</th>
      <th>aspiration</th>
      <th>num-of-doors</th>
      <th>body-style</th>
      <th>drive-wheels</th>
      <th>engine-location</th>
      <th>wheel-base</th>
      <th>...</th>
      <th>engine-size</th>
      <th>fuel-system</th>
      <th>bore</th>
      <th>stroke</th>
      <th>compression-ratio</th>
      <th>horsepower</th>
      <th>peak-rpm</th>
      <th>city-mpg</th>
      <th>highway-mpg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>...</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
      <td>205.000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>0.834</td>
      <td>122.000</td>
      <td>12.195</td>
      <td>0.902</td>
      <td>0.180</td>
      <td>0.434</td>
      <td>2.615</td>
      <td>1.327</td>
      <td>0.015</td>
      <td>98.757</td>
      <td>...</td>
      <td>126.907</td>
      <td>3.254</td>
      <td>3.330</td>
      <td>3.255</td>
      <td>10.143</td>
      <td>104.256</td>
      <td>5125.369</td>
      <td>25.220</td>
      <td>30.751</td>
      <td>13207.129</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.245</td>
      <td>31.681</td>
      <td>6.275</td>
      <td>0.297</td>
      <td>0.386</td>
      <td>0.497</td>
      <td>0.859</td>
      <td>0.556</td>
      <td>0.120</td>
      <td>6.022</td>
      <td>...</td>
      <td>41.643</td>
      <td>2.013</td>
      <td>0.271</td>
      <td>0.314</td>
      <td>3.972</td>
      <td>39.519</td>
      <td>476.979</td>
      <td>6.542</td>
      <td>6.886</td>
      <td>7868.768</td>
    </tr>
    <tr>
      <th>min</th>
      <td>-2.000</td>
      <td>65.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>86.600</td>
      <td>...</td>
      <td>61.000</td>
      <td>0.000</td>
      <td>2.540</td>
      <td>2.070</td>
      <td>7.000</td>
      <td>48.000</td>
      <td>4150.000</td>
      <td>13.000</td>
      <td>16.000</td>
      <td>5118.000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>0.000</td>
      <td>101.000</td>
      <td>8.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>2.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>94.500</td>
      <td>...</td>
      <td>97.000</td>
      <td>1.000</td>
      <td>3.150</td>
      <td>3.110</td>
      <td>8.600</td>
      <td>70.000</td>
      <td>4800.000</td>
      <td>19.000</td>
      <td>25.000</td>
      <td>7788.000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1.000</td>
      <td>122.000</td>
      <td>12.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>3.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>97.000</td>
      <td>...</td>
      <td>120.000</td>
      <td>5.000</td>
      <td>3.310</td>
      <td>3.290</td>
      <td>9.000</td>
      <td>95.000</td>
      <td>5200.000</td>
      <td>24.000</td>
      <td>30.000</td>
      <td>10595.000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2.000</td>
      <td>137.000</td>
      <td>19.000</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>1.000</td>
      <td>3.000</td>
      <td>2.000</td>
      <td>0.000</td>
      <td>102.400</td>
      <td>...</td>
      <td>141.000</td>
      <td>5.000</td>
      <td>3.580</td>
      <td>3.410</td>
      <td>9.400</td>
      <td>116.000</td>
      <td>5500.000</td>
      <td>30.000</td>
      <td>34.000</td>
      <td>16500.000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>3.000</td>
      <td>256.000</td>
      <td>21.000</td>
      <td>1.000</td>
      <td>1.000</td>
      <td>1.000</td>
      <td>4.000</td>
      <td>2.000</td>
      <td>1.000</td>
      <td>120.900</td>
      <td>...</td>
      <td>326.000</td>
      <td>7.000</td>
      <td>3.940</td>
      <td>4.170</td>
      <td>23.000</td>
      <td>288.000</td>
      <td>6600.000</td>
      <td>49.000</td>
      <td>54.000</td>
      <td>45400.000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 26 columns</p>
</div>




```python
# correlation coefficient

corr = Auto1.corr()
cmap = cmap=sns.diverging_palette(5, 250, as_cmap=True)

def magnify():
    return [dict(selector="th",
                 props=[("font-size", "7pt")]),
            dict(selector="td",
                 props=[('padding', "0em 0em")]),
            dict(selector="th:hover",
                 props=[("font-size", "12pt")]),
            dict(selector="tr:hover td:hover",
                 props=[('max-width', '200px'),
                        ('font-size', '12pt')])
            ]

corr.style.background_gradient(cmap, axis=1)\
    .set_properties(**{'max-width': '80px', 'font-size': '9pt'})\
    .set_caption("CORRELATION RELATIONSHIP BETWEEN VARIABLES")\
    .set_precision(4)\
    .set_table_styles(magnify())
```




<style  type="text/css" >
    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50 th {
          font-size: 7pt;
    }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50 td {
          padding: 0em 0em;
    }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50 th:hover {
          font-size: 12pt;
    }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50 tr:hover td:hover {
          max-width: 200px;
          font-size: 12pt;
    }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col0 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col1 {
            background-color:  #b9cde6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col2 {
            background-color:  #eda8b6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col3 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col4 {
            background-color:  #f0b7c2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col5 {
            background-color:  #8dadd5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col6 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col7 {
            background-color:  #f1b9c4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col8 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col9 {
            background-color:  #da4966;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col10 {
            background-color:  #e27288;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col11 {
            background-color:  #e88ea0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col12 {
            background-color:  #d94764;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col13 {
            background-color:  #e890a1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col14 {
            background-color:  #f5cfd7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col15 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col16 {
            background-color:  #eeabb8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col17 {
            background-color:  #f7d9df;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col18 {
            background-color:  #eda6b4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col19 {
            background-color:  #f3c2cc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col20 {
            background-color:  #ea9aaa;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col21 {
            background-color:  #f6d5db;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col22 {
            background-color:  #e4ecf5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col23 {
            background-color:  #f1bbc6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col24 {
            background-color:  #f5ccd4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col25 {
            background-color:  #efb1be;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col0 {
            background-color:  #cddbed;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col1 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col2 {
            background-color:  #de5b75;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col3 {
            background-color:  #f1b9c4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col4 {
            background-color:  #eb9bab;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col5 {
            background-color:  #eaf0f7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col6 {
            background-color:  #de5b75;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col7 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col8 {
            background-color:  #eb9ead;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col9 {
            background-color:  #e88ea0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col10 {
            background-color:  #eca3b1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col11 {
            background-color:  #f0b4c0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col12 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col13 {
            background-color:  #f1b8c3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col14 {
            background-color:  #e7879b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col15 {
            background-color:  #f4cad3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col16 {
            background-color:  #f1bbc6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col17 {
            background-color:  #f7dae0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col18 {
            background-color:  #ea96a7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col19 {
            background-color:  #eeacba;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col20 {
            background-color:  #e57f93;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col21 {
            background-color:  #f6d5db;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col22 {
            background-color:  #f8dee3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col23 {
            background-color:  #df637c;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col24 {
            background-color:  #e16d85;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col25 {
            background-color:  #f3c2cc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col0 {
            background-color:  #df627b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col1 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col2 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col3 {
            background-color:  #df637c;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col4 {
            background-color:  #e994a5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col5 {
            background-color:  #dd5872;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col6 {
            background-color:  #eb9ead;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col7 {
            background-color:  #e68396;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col8 {
            background-color:  #e994a5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col9 {
            background-color:  #eb9bab;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col10 {
            background-color:  #eda7b5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col11 {
            background-color:  #e68699;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col12 {
            background-color:  #f4c9d2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col13 {
            background-color:  #e78c9e;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col14 {
            background-color:  #e3748a;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col15 {
            background-color:  #e4798e;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col16 {
            background-color:  #e26f86;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col17 {
            background-color:  #efafbc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col18 {
            background-color:  #f5ced6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col19 {
            background-color:  #da4966;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col20 {
            background-color:  #eeacba;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col21 {
            background-color:  #e3748a;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col22 {
            background-color:  #d94462;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col23 {
            background-color:  #e994a5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col24 {
            background-color:  #e993a4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col25 {
            background-color:  #dc5570;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col0 {
            background-color:  #d3dfef;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col1 {
            background-color:  #e3ebf5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col2 {
            background-color:  #f8dce2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col3 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col4 {
            background-color:  #eda7b5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col5 {
            background-color:  #d4e0ef;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col6 {
            background-color:  #f6d5db;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col7 {
            background-color:  #f7d7de;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col8 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col9 {
            background-color:  #f1b8c3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col10 {
            background-color:  #f4c9d2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col11 {
            background-color:  #f3c5ce;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col12 {
            background-color:  #f1bcc7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col13 {
            background-color:  #f4c8d0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col14 {
            background-color:  #e7eef6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col15 {
            background-color:  #e2eaf4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col16 {
            background-color:  #fae4e9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col17 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col18 {
            background-color:  #fae6ea;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col19 {
            background-color:  #f3c4cd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col20 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col21 {
            background-color:  #d8e3f1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col22 {
            background-color:  #a0bbdc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col23 {
            background-color:  #f2c1cb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col24 {
            background-color:  #f5ced6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col25 {
            background-color:  #f8dce2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col0 {
            background-color:  #e994a5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col1 {
            background-color:  #eca3b1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col2 {
            background-color:  #efb2bf;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col3 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col4 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col5 {
            background-color:  #ea96a7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col6 {
            background-color:  #f0b4c0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col7 {
            background-color:  #f0b5c1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col8 {
            background-color:  #e994a5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col9 {
            background-color:  #fae7eb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col10 {
            background-color:  #f9e2e6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col11 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col12 {
            background-color:  #f1bbc6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col13 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col14 {
            background-color:  #e7899c;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col15 {
            background-color:  #e58195;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col16 {
            background-color:  #f2c1cb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col17 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col18 {
            background-color:  #f8dce2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col19 {
            background-color:  #f8dfe4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col20 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col21 {
            background-color:  #f9e3e7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col22 {
            background-color:  #e27389;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col23 {
            background-color:  #e26f86;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col24 {
            background-color:  #df617a;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col25 {
            background-color:  #f6d2d9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col0 {
            background-color:  #8babd4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col1 {
            background-color:  #cad9ec;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col2 {
            background-color:  #efafbc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col3 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col4 {
            background-color:  #f3c5ce;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col5 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col6 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col7 {
            background-color:  #fae7eb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col8 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col9 {
            background-color:  #e27087;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col10 {
            background-color:  #e47c91;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col11 {
            background-color:  #eda6b4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col12 {
            background-color:  #de5b75;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col13 {
            background-color:  #eda7b5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col14 {
            background-color:  #f8dee3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col15 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col16 {
            background-color:  #f5ced6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col17 {
            background-color:  #f6d2d9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col18 {
            background-color:  #f1b8c3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col19 {
            background-color:  #f6d2d9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col20 {
            background-color:  #eeabb8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col21 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col22 {
            background-color:  #e3ebf5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col23 {
            background-color:  #f6d3da;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col24 {
            background-color:  #f7d7de;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col25 {
            background-color:  #f3c6cf;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col0 {
            background-color:  #db4e6a;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col1 {
            background-color:  #ea9aaa;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col2 {
            background-color:  #f9e3e7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col3 {
            background-color:  #efafbc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col4 {
            background-color:  #f8dee3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col5 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col6 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col7 {
            background-color:  #eeaebb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col8 {
            background-color:  #e994a5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col9 {
            background-color:  #c0d2e8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col10 {
            background-color:  #cfddee;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col11 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col12 {
            background-color:  #9eb9db;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col13 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col14 {
            background-color:  #f4c8d0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col15 {
            background-color:  #f3c5ce;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col16 {
            background-color:  #f2bfca;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col17 {
            background-color:  #f3c2cc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col18 {
            background-color:  #f6d2d9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col19 {
            background-color:  #f5ccd4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col20 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col21 {
            background-color:  #eeaebb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col22 {
            background-color:  #f1b8c3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col23 {
            background-color:  #f7d6dd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col24 {
            background-color:  #f5cfd7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col25 {
            background-color:  #f2c1cb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col0 {
            background-color:  #eca3b1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col1 {
            background-color:  #ebf1f8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col2 {
            background-color:  #eeabb8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col3 {
            background-color:  #e78c9e;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col4 {
            background-color:  #f2bdc8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col5 {
            background-color:  #f4c8d0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col6 {
            background-color:  #e68699;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col7 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col8 {
            background-color:  #f6d2d9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col9 {
            background-color:  #c7d7eb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col10 {
            background-color:  #c0d2e8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col11 {
            background-color:  #c5d5ea;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col12 {
            background-color:  #eda8b6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col13 {
            background-color:  #aac2e0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col14 {
            background-color:  #e890a1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col15 {
            background-color:  #fae6ea;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col16 {
            background-color:  #b7cbe5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col17 {
            background-color:  #cfddee;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col18 {
            background-color:  #c1d3e8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col19 {
            background-color:  #f2bfca;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col20 {
            background-color:  #f5ced6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col21 {
            background-color:  #b9cde6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col22 {
            background-color:  #eca3b1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col23 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col24 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col25 {
            background-color:  #aac2e0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col0 {
            background-color:  #f4c8d0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col1 {
            background-color:  #e78a9d;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col2 {
            background-color:  #ea9aaa;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col3 {
            background-color:  #ea96a7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col4 {
            background-color:  #e47a90;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col5 {
            background-color:  #efb2bf;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col6 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col7 {
            background-color:  #f0b5c1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col8 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col9 {
            background-color:  #dc546f;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col10 {
            background-color:  #e47c91;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col11 {
            background-color:  #e47c91;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col12 {
            background-color:  #e16c84;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col13 {
            background-color:  #ea99a9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col14 {
            background-color:  #eeabb8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col15 {
            background-color:  #efb1be;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col16 {
            background-color:  #f3c2cc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col17 {
            background-color:  #eda8b6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col18 {
            background-color:  #f2bfca;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col19 {
            background-color:  #df627b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col20 {
            background-color:  #e68598;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col21 {
            background-color:  #fae6ea;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col22 {
            background-color:  #f3c4cd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col23 {
            background-color:  #de5e77;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col24 {
            background-color:  #e16d85;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col25 {
            background-color:  #fae8ec;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col0 {
            background-color:  #d83e5d;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col1 {
            background-color:  #eeaebb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col2 {
            background-color:  #f5cfd7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col3 {
            background-color:  #e27389;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col4 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col5 {
            background-color:  #dc546f;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col6 {
            background-color:  #cddbed;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col7 {
            background-color:  #bfd1e8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col8 {
            background-color:  #e890a1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col9 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col10 {
            background-color:  #5f8cc5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col11 {
            background-color:  #7199cb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col12 {
            background-color:  #a2bcdd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col13 {
            background-color:  #779dcd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col14 {
            background-color:  #eb9bab;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col15 {
            background-color:  #e890a1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col16 {
            background-color:  #a6bfde;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col17 {
            background-color:  #d1deee;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col18 {
            background-color:  #b8cce5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col19 {
            background-color:  #f9e2e6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col20 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col21 {
            background-color:  #d8e3f1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col22 {
            background-color:  #e0667e;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col23 {
            background-color:  #db4d69;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col24 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col25 {
            background-color:  #a3bddd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col0 {
            background-color:  #e68699;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col1 {
            background-color:  #f7d6dd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col2 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col3 {
            background-color:  #eca4b3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col4 {
            background-color:  #e2eaf4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col5 {
            background-color:  #e57f93;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col6 {
            background-color:  #cddbed;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col7 {
            background-color:  #aec5e1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col8 {
            background-color:  #f4c8d0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col9 {
            background-color:  #5c8ac4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col10 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col11 {
            background-color:  #6490c6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col12 {
            background-color:  #adc4e1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col13 {
            background-color:  #5c8ac4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col14 {
            background-color:  #f1b9c4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col15 {
            background-color:  #f1bbc6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col16 {
            background-color:  #85a7d2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col17 {
            background-color:  #9fbadc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col18 {
            background-color:  #95b3d8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col19 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col20 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col21 {
            background-color:  #9fbadc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col22 {
            background-color:  #e994a5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col23 {
            background-color:  #d94261;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col24 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col25 {
            background-color:  #85a7d2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col0 {
            background-color:  #eb9bab;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col1 {
            background-color:  #f9e2e6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col2 {
            background-color:  #f5cfd7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col3 {
            background-color:  #eb9bab;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col4 {
            background-color:  #d7e2f0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col5 {
            background-color:  #eca4b3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col6 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col7 {
            background-color:  #b2c8e3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col8 {
            background-color:  #f3c4cd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col9 {
            background-color:  #6f98ca;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col10 {
            background-color:  #6590c7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col11 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col12 {
            background-color:  #dce6f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col13 {
            background-color:  #5f8cc5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col14 {
            background-color:  #f6d2d9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col15 {
            background-color:  #eca4b3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col16 {
            background-color:  #7ba0cf;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col17 {
            background-color:  #a9c1e0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col18 {
            background-color:  #a0bbdc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col19 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col20 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col21 {
            background-color:  #8faed6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col22 {
            background-color:  #eb9ead;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col23 {
            background-color:  #d94261;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col24 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col25 {
            background-color:  #7da2cf;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col0 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col1 {
            background-color:  #df637c;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col2 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col3 {
            background-color:  #e3788d;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col4 {
            background-color:  #f6d1d8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col5 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col6 {
            background-color:  #a6bfde;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col7 {
            background-color:  #f0b7c2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col8 {
            background-color:  #eca3b1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col9 {
            background-color:  #a2bcdd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col10 {
            background-color:  #b8cce5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col11 {
            background-color:  #e8eff7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col12 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col13 {
            background-color:  #e6edf6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col14 {
            background-color:  #eb9dac;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col15 {
            background-color:  #e3788d;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col16 {
            background-color:  #f5ccd4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col17 {
            background-color:  #f2bfca;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col18 {
            background-color:  #fae4e9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col19 {
            background-color:  #eeaebb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col20 {
            background-color:  #ecf2f8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col21 {
            background-color:  #eca1b0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col22 {
            background-color:  #e26f86;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col23 {
            background-color:  #efafbc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col24 {
            background-color:  #eca3b1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col25 {
            background-color:  #f8dce2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col0 {
            background-color:  #efafbc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col1 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col2 {
            background-color:  #f9e2e6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col3 {
            background-color:  #efb1be;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col4 {
            background-color:  #c9d8eb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col5 {
            background-color:  #f0b7c2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col6 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col7 {
            background-color:  #96b4d9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col8 {
            background-color:  #fae7eb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col9 {
            background-color:  #6f98ca;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col10 {
            background-color:  #5b89c3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col11 {
            background-color:  #5c8ac4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col12 {
            background-color:  #cedced;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col13 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col14 {
            background-color:  #f6d2d9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col15 {
            background-color:  #f6d3da;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col16 {
            background-color:  #618ec5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col17 {
            background-color:  #90afd6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col18 {
            background-color:  #89aad4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col19 {
            background-color:  #e7eef6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col20 {
            background-color:  #eaf0f7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col21 {
            background-color:  #749bcc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col22 {
            background-color:  #eda7b5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col23 {
            background-color:  #d94261;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col24 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col25 {
            background-color:  #6691c7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col0 {
            background-color:  #e4798e;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col1 {
            background-color:  #db4d69;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col2 {
            background-color:  #dd5872;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col3 {
            background-color:  #e68396;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col4 {
            background-color:  #d94764;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col5 {
            background-color:  #e47c91;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col6 {
            background-color:  #de5c76;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col7 {
            background-color:  #d94261;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col8 {
            background-color:  #e88d9f;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col9 {
            background-color:  #d73d5c;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col10 {
            background-color:  #d94462;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col11 {
            background-color:  #e16c84;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col12 {
            background-color:  #d8405e;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col13 {
            background-color:  #dd5671;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col14 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col15 {
            background-color:  #f0b5c1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col16 {
            background-color:  #e3748a;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col17 {
            background-color:  #da4b68;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col18 {
            background-color:  #e27288;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col19 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col20 {
            background-color:  #dc516d;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col21 {
            background-color:  #e16c84;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col22 {
            background-color:  #e16b82;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col23 {
            background-color:  #db4d69;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col24 {
            background-color:  #db4f6b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col25 {
            background-color:  #e57f93;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col0 {
            background-color:  #f3c5ce;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col1 {
            background-color:  #f1bbc6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col2 {
            background-color:  #e58094;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col3 {
            background-color:  #eeabb8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col4 {
            background-color:  #e0667e;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col5 {
            background-color:  #f1b8c3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col6 {
            background-color:  #e57d92;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col7 {
            background-color:  #f5ccd4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col8 {
            background-color:  #efb2bf;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col9 {
            background-color:  #dd5671;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col10 {
            background-color:  #e16c84;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col11 {
            background-color:  #dc546f;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col12 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col13 {
            background-color:  #e57f93;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col14 {
            background-color:  #f5cfd7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col15 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col16 {
            background-color:  #e27389;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col17 {
            background-color:  #e88ea0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col18 {
            background-color:  #e68396;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col19 {
            background-color:  #e57d92;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col20 {
            background-color:  #e4798e;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col21 {
            background-color:  #eeacba;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col22 {
            background-color:  #f4cad3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col23 {
            background-color:  #e06880;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col24 {
            background-color:  #e27389;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col25 {
            background-color:  #e88d9f;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col0 {
            background-color:  #f1b8c3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col1 {
            background-color:  #fae7eb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col2 {
            background-color:  #f2bfca;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col3 {
            background-color:  #f2bfca;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col4 {
            background-color:  #fae6ea;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col5 {
            background-color:  #f5ccd4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col6 {
            background-color:  #f2bfca;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col7 {
            background-color:  #a8c0df;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col8 {
            background-color:  #ecf2f8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col9 {
            background-color:  #9eb9db;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col10 {
            background-color:  #86a8d3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col11 {
            background-color:  #7ba0cf;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col12 {
            background-color:  #f8dee3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col13 {
            background-color:  #628fc6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col14 {
            background-color:  #f7d7de;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col15 {
            background-color:  #f1bcc7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col16 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col17 {
            background-color:  #aac2e0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col18 {
            background-color:  #9bb7da;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col19 {
            background-color:  #ebf1f8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col20 {
            background-color:  #f6d5db;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col21 {
            background-color:  #6a94c9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col22 {
            background-color:  #ea9aaa;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col23 {
            background-color:  #d8405e;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col24 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col25 {
            background-color:  #618ec5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col0 {
            background-color:  #f9e2e6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col1 {
            background-color:  #e7eef6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col2 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col3 {
            background-color:  #f7d7de;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col4 {
            background-color:  #dae5f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col5 {
            background-color:  #f5cfd7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col6 {
            background-color:  #f2bfca;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col7 {
            background-color:  #bdd0e7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col8 {
            background-color:  #fae6ea;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col9 {
            background-color:  #c6d6ea;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col10 {
            background-color:  #a0bbdc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col11 {
            background-color:  #a9c1e0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col12 {
            background-color:  #f6d2d9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col13 {
            background-color:  #95b3d8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col14 {
            background-color:  #f1b9c4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col15 {
            background-color:  #f6d1d8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col16 {
            background-color:  #aac2e0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col17 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col18 {
            background-color:  #b2c8e3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col19 {
            background-color:  #f9e2e6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col20 {
            background-color:  #f1b8c3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col21 {
            background-color:  #8cacd5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col22 {
            background-color:  #f6d2d9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col23 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col24 {
            background-color:  #d8405e;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col25 {
            background-color:  #aac2e0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col0 {
            background-color:  #eca4b3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col1 {
            background-color:  #f1bbc6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col2 {
            background-color:  #eaf0f7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col3 {
            background-color:  #f0b5c1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col4 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col5 {
            background-color:  #eeaab7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col6 {
            background-color:  #f3c5ce;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col7 {
            background-color:  #b7cbe5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col8 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col9 {
            background-color:  #b5cae4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col10 {
            background-color:  #9bb7da;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col11 {
            background-color:  #a6bfde;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col12 {
            background-color:  #fbeaed;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col13 {
            background-color:  #91b0d7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col14 {
            background-color:  #f4c9d2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col15 {
            background-color:  #f1bbc6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col16 {
            background-color:  #a0bbdc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col17 {
            background-color:  #b8cce5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col18 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col19 {
            background-color:  #f0b5c1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col20 {
            background-color:  #f3c4cd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col21 {
            background-color:  #a2bcdd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col22 {
            background-color:  #e7879b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col23 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col24 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col25 {
            background-color:  #acc3e1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col0 {
            background-color:  #e58094;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col1 {
            background-color:  #e993a4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col2 {
            background-color:  #d94764;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col3 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col4 {
            background-color:  #f3c4cd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col5 {
            background-color:  #e68598;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col6 {
            background-color:  #e57d92;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col7 {
            background-color:  #ea97a8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col8 {
            background-color:  #dd5a74;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col9 {
            background-color:  #efb2bf;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col10 {
            background-color:  #eda8b6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col11 {
            background-color:  #f1b8c3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col12 {
            background-color:  #e27288;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col13 {
            background-color:  #f0b4c0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col14 {
            background-color:  #dd5872;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col15 {
            background-color:  #e27389;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col16 {
            background-color:  #f2bdc8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col17 {
            background-color:  #eb9dac;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col18 {
            background-color:  #e27288;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col19 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col20 {
            background-color:  #f1b9c4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col21 {
            background-color:  #eb9dac;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col22 {
            background-color:  #e26f86;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col23 {
            background-color:  #e3768c;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col24 {
            background-color:  #e3748a;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col25 {
            background-color:  #ea9aaa;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col0 {
            background-color:  #f5cfd7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col1 {
            background-color:  #f8dce2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col2 {
            background-color:  #dde7f3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col3 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col4 {
            background-color:  #c0d2e8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col5 {
            background-color:  #f6d1d8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col6 {
            background-color:  #dde7f3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col7 {
            background-color:  #dfe8f3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col8 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col9 {
            background-color:  #c9d8eb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col10 {
            background-color:  #d9e4f1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col11 {
            background-color:  #d5e1f0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col12 {
            background-color:  #c7d7eb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col13 {
            background-color:  #dae5f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col14 {
            background-color:  #f9e3e7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col15 {
            background-color:  #fae4e9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col16 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col17 {
            background-color:  #f8dee3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col18 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col19 {
            background-color:  #d4e0ef;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col20 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col21 {
            background-color:  #f4cad3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col22 {
            background-color:  #ec9faf;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col23 {
            background-color:  #bccfe7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col24 {
            background-color:  #c6d6ea;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col25 {
            background-color:  #e8eff7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col0 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col1 {
            background-color:  #e0e9f4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col2 {
            background-color:  #f6d3da;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col3 {
            background-color:  #e7eef6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col4 {
            background-color:  #d8e3f1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col5 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col6 {
            background-color:  #f2bfca;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col7 {
            background-color:  #a2bcdd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col8 {
            background-color:  #c9d8eb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col9 {
            background-color:  #c3d4e9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col10 {
            background-color:  #9bb7da;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col11 {
            background-color:  #89aad4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col12 {
            background-color:  #f4c8d0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col13 {
            background-color:  #749bcc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col14 {
            background-color:  #f9e0e5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col15 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col16 {
            background-color:  #6892c8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col17 {
            background-color:  #86a8d3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col18 {
            background-color:  #96b4d9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col19 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col20 {
            background-color:  #f0b4c0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col21 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col22 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col23 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col24 {
            background-color:  #d8415f;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col25 {
            background-color:  #739acc;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col0 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col1 {
            background-color:  #fae7eb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col2 {
            background-color:  #e27288;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col3 {
            background-color:  #c5d5ea;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col4 {
            background-color:  #e47a90;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col5 {
            background-color:  #fae7eb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col6 {
            background-color:  #e88ea0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col7 {
            background-color:  #ec9faf;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col8 {
            background-color:  #f8dee3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col9 {
            background-color:  #db4e6a;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col10 {
            background-color:  #df617a;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col11 {
            background-color:  #e27288;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col12 {
            background-color:  #dd5872;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col13 {
            background-color:  #e0667e;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col14 {
            background-color:  #eeabb8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col15 {
            background-color:  #f9e3e7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col16 {
            background-color:  #e16c84;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col17 {
            background-color:  #eeaebb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col18 {
            background-color:  #e16981;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col19 {
            background-color:  #ea99a9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col20 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col21 {
            background-color:  #f5ccd4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col22 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col23 {
            background-color:  #e88d9f;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col24 {
            background-color:  #eb9dac;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col25 {
            background-color:  #e890a1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col0 {
            background-color:  #f7d6dd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col1 {
            background-color:  #efb1be;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col2 {
            background-color:  #fae8ec;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col3 {
            background-color:  #eeaab7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col4 {
            background-color:  #f0b5c1;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col5 {
            background-color:  #f9e2e6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col6 {
            background-color:  #fae4e9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col7 {
            background-color:  #e68396;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col8 {
            background-color:  #f2bfca;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col9 {
            background-color:  #e57f93;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col10 {
            background-color:  #dc5570;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col11 {
            background-color:  #de5b75;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col12 {
            background-color:  #f6d5db;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col13 {
            background-color:  #d94462;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col14 {
            background-color:  #f5ccd4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col15 {
            background-color:  #f3c5ce;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col16 {
            background-color:  #dd5a74;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col17 {
            background-color:  #dc5570;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col18 {
            background-color:  #e06880;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col19 {
            background-color:  #f7d6dd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col20 {
            background-color:  #c7d7eb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col21 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col22 {
            background-color:  #f3c6cf;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col23 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col24 {
            background-color:  #497dbd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col25 {
            background-color:  #dd5671;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col0 {
            background-color:  #fae4e9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col1 {
            background-color:  #f1b9c4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col2 {
            background-color:  #fae7eb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col3 {
            background-color:  #f0b7c2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col4 {
            background-color:  #eeaab7;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col5 {
            background-color:  #fae4e9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col6 {
            background-color:  #f8dce2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col7 {
            background-color:  #e58195;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col8 {
            background-color:  #f4c9d2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col9 {
            background-color:  #e26f86;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col10 {
            background-color:  #db4e6a;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col11 {
            background-color:  #dc546f;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col12 {
            background-color:  #f4c8d0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col13 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col14 {
            background-color:  #f5ced6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col15 {
            background-color:  #f5ccd4;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col16 {
            background-color:  #dc546f;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col17 {
            background-color:  #dd5a74;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col18 {
            background-color:  #e0657d;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col19 {
            background-color:  #f6d5db;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col20 {
            background-color:  #d4e0ef;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col21 {
            background-color:  #d8405e;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col22 {
            background-color:  #f6d2d9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col23 {
            background-color:  #497dbd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col24 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col25 {
            background-color:  #dc516d;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col0 {
            background-color:  #f2bfca;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col1 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col2 {
            background-color:  #eeaebb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col3 {
            background-color:  #f1b8c3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col4 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col5 {
            background-color:  #f4c8d0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col6 {
            background-color:  #f2c1cb;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col7 {
            background-color:  #9cb8db;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col8 {
            background-color:  #cfddee;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col9 {
            background-color:  #9bb7da;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col10 {
            background-color:  #86a8d3;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col11 {
            background-color:  #7da2cf;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col12 {
            background-color:  #f2f2f2;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col13 {
            background-color:  #6993c8;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col14 {
            background-color:  #f9e0e5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col15 {
            background-color:  #f6d2d9;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col16 {
            background-color:  #5f8cc5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col17 {
            background-color:  #a9c1e0;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col18 {
            background-color:  #a4bede;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col19 {
            background-color:  #f9e2e6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col20 {
            background-color:  #f9e0e5;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col21 {
            background-color:  #759ccd;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col22 {
            background-color:  #f1bbc6;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col23 {
            background-color:  #d8405e;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col24 {
            background-color:  #d73c5b;
            max-width:  80px;
            font-size:  9pt;
        }    #T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col25 {
            background-color:  #4479bb;
            max-width:  80px;
            font-size:  9pt;
        }</style>  
<table id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50" ><caption>CORRELATION RELATIONSHIP BETWEEN VARIABLES</caption> 
<thead>    <tr> 
        <th class="blank level0" ></th> 
        <th class="col_heading level0 col0" >symboling</th> 
        <th class="col_heading level0 col1" >normalized-losses</th> 
        <th class="col_heading level0 col2" >make</th> 
        <th class="col_heading level0 col3" >fuel-type</th> 
        <th class="col_heading level0 col4" >aspiration</th> 
        <th class="col_heading level0 col5" >num-of-doors</th> 
        <th class="col_heading level0 col6" >body-style</th> 
        <th class="col_heading level0 col7" >drive-wheels</th> 
        <th class="col_heading level0 col8" >engine-location</th> 
        <th class="col_heading level0 col9" >wheel-base</th> 
        <th class="col_heading level0 col10" >length</th> 
        <th class="col_heading level0 col11" >width</th> 
        <th class="col_heading level0 col12" >height</th> 
        <th class="col_heading level0 col13" >curb-weight</th> 
        <th class="col_heading level0 col14" >engine-type</th> 
        <th class="col_heading level0 col15" >num-of-cylinders</th> 
        <th class="col_heading level0 col16" >engine-size</th> 
        <th class="col_heading level0 col17" >fuel-system</th> 
        <th class="col_heading level0 col18" >bore</th> 
        <th class="col_heading level0 col19" >stroke</th> 
        <th class="col_heading level0 col20" >compression-ratio</th> 
        <th class="col_heading level0 col21" >horsepower</th> 
        <th class="col_heading level0 col22" >peak-rpm</th> 
        <th class="col_heading level0 col23" >city-mpg</th> 
        <th class="col_heading level0 col24" >highway-mpg</th> 
        <th class="col_heading level0 col25" >price</th> 
    </tr></thead> 
<tbody>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row0" class="row_heading level0 row0" >symboling</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col0" class="data row0 col0" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col1" class="data row0 col1" >0.4652</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col2" class="data row0 col2" >-0.1188</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col3" class="data row0 col3" >0.1943</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col4" class="data row0 col4" >-0.05987</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col5" class="data row0 col5" >0.6636</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col6" class="data row0 col6" >-0.5961</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col7" class="data row0 col7" >-0.04167</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col8" class="data row0 col8" >0.2125</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col9" class="data row0 col9" >-0.532</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col10" class="data row0 col10" >-0.3576</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col11" class="data row0 col11" >-0.2329</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col12" class="data row0 col12" >-0.541</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col13" class="data row0 col13" >-0.2277</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col14" class="data row0 col14" >0.05037</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col15" class="data row0 col15" >0.1978</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col16" class="data row0 col16" >-0.1058</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col17" class="data row0 col17" >0.09116</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col18" class="data row0 col18" >-0.1301</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col19" class="data row0 col19" >-0.008689</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col20" class="data row0 col20" >-0.1785</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col21" class="data row0 col21" >0.07139</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col22" class="data row0 col22" >0.2737</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col23" class="data row0 col23" >-0.03582</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col24" class="data row0 col24" >0.03461</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row0_col25" class="data row0 col25" >-0.0822</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row1" class="row_heading level0 row1" >normalized-losses</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col0" class="data row1 col0" >0.4652</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col1" class="data row1 col1" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col2" class="data row1 col2" >-0.251</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col3" class="data row1 col3" >0.1014</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col4" class="data row1 col4" >-0.006823</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col5" class="data row1 col5" >0.3572</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col6" class="data row1 col6" >-0.2509</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col7" class="data row1 col7" >0.311</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col8" class="data row1 col8" >4.281e-19</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col9" class="data row1 col9" >-0.05652</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col10" class="data row1 col10" >0.01921</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col11" class="data row1 col11" >0.08419</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col12" class="data row1 col12" >-0.3707</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col13" class="data row1 col13" >0.09779</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col14" class="data row1 col14" >-0.0842</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col15" class="data row1 col15" >0.1668</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col16" class="data row1 col16" >0.111</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col17" class="data row1 col17" >0.228</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col18" class="data row1 col18" >-0.02927</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col19" class="data row1 col19" >0.05493</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col20" class="data row1 col20" >-0.1145</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col21" class="data row1 col21" >0.2034</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col22" class="data row1 col22" >0.2377</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col23" class="data row1 col23" >-0.2187</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col24" class="data row1 col24" >-0.1782</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row1_col25" class="data row1 col25" >0.134</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row2" class="row_heading level0 row2" >make</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col0" class="data row2 col0" >-0.1188</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col1" class="data row2 col1" >-0.251</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col2" class="data row2 col2" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col3" class="data row2 col3" >-0.1132</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col4" class="data row2 col4" >0.05427</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col5" class="data row2 col5" >-0.1515</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col6" class="data row2 col6" >0.08949</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col7" class="data row2 col7" >-0.004317</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col8" class="data row2 col8" >0.05461</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col9" class="data row2 col9" >0.0785</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col10" class="data row2 col10" >0.1196</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col11" class="data row2 col11" >0.003783</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col12" class="data row2 col12" >0.2362</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col13" class="data row2 col13" >0.02402</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col14" class="data row2 col14" >-0.05154</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col15" class="data row2 col15" >-0.03994</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col16" class="data row2 col16" >-0.07092</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col17" class="data row2 col17" >0.1466</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col18" class="data row2 col18" >0.2512</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col19" class="data row2 col19" >-0.201</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col20" class="data row2 col20" >0.1388</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col21" class="data row2 col21" >-0.05365</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col22" class="data row2 col22" >-0.2183</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col23" class="data row2 col23" >0.05364</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col24" class="data row2 col24" >0.05002</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row2_col25" class="data row2 col25" >-0.1615</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row3" class="row_heading level0 row3" >fuel-type</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col0" class="data row3 col0" >0.1943</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col1" class="data row3 col1" >0.1014</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col2" class="data row3 col2" >-0.1132</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col3" class="data row3 col3" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col4" class="data row3 col4" >-0.4014</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col5" class="data row3 col5" >0.1885</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col6" class="data row3 col6" >-0.1479</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col7" class="data row3 col7" >-0.1323</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col8" class="data row3 col8" >0.04007</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col9" class="data row3 col9" >-0.3083</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col10" class="data row3 col10" >-0.2127</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col11" class="data row3 col11" >-0.2339</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col12" class="data row3 col12" >-0.2846</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col13" class="data row3 col13" >-0.2173</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col14" class="data row3 col14" >0.0827</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col15" class="data row3 col15" >0.1106</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col16" class="data row3 col16" >-0.06959</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col17" class="data row3 col17" >0.04153</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col18" class="data row3 col18" >-0.05446</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col19" class="data row3 col19" >-0.2418</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col20" class="data row3 col20" >-0.9844</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col21" class="data row3 col21" >0.1652</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col22" class="data row3 col22" >0.4771</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col23" class="data row3 col23" >-0.256</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col24" class="data row3 col24" >-0.1914</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row3_col25" class="data row3 col25" >-0.1102</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row4" class="row_heading level0 row4" >aspiration</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col0" class="data row4 col0" >-0.05987</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col1" class="data row4 col1" >-0.006823</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col2" class="data row4 col2" >0.05427</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col3" class="data row4 col3" >-0.4014</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col4" class="data row4 col4" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col5" class="data row4 col5" >-0.0528</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col6" class="data row4 col6" >0.06303</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col7" class="data row4 col7" >0.06646</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col8" class="data row4 col8" >-0.05719</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col9" class="data row4 col9" >0.2576</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col10" class="data row4 col10" >0.2345</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col11" class="data row4 col11" >0.3006</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col12" class="data row4 col12" >0.08731</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col13" class="data row4 col13" >0.3249</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col14" class="data row4 col14" >-0.103</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col15" class="data row4 col15" >-0.1331</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col16" class="data row4 col16" >0.1082</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col17" class="data row4 col17" >0.2881</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col18" class="data row4 col18" >0.2126</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col19" class="data row4 col19" >0.223</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col20" class="data row4 col20" >0.2955</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col21" class="data row4 col21" >0.2402</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col22" class="data row4 col22" >-0.1836</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col23" class="data row4 col23" >-0.2024</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col24" class="data row4 col24" >-0.2544</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row4_col25" class="data row4 col25" >0.1773</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row5" class="row_heading level0 row5" >num-of-doors</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col0" class="data row5 col0" >0.6636</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col1" class="data row5 col1" >0.3572</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col2" class="data row5 col2" >-0.1515</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col3" class="data row5 col3" >0.1885</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col4" class="data row5 col4" >-0.0528</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col5" class="data row5 col5" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col6" class="data row5 col6" >-0.6856</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col7" class="data row5 col7" >0.1049</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col8" class="data row5 col8" >0.1391</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col9" class="data row5 col9" >-0.4396</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col10" class="data row5 col10" >-0.3857</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col11" class="data row5 col11" >-0.1977</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col12" class="data row5 col12" >-0.5403</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col13" class="data row5 col13" >-0.1907</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col14" class="data row5 col14" >0.06265</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col15" class="data row5 col15" >0.156</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col16" class="data row5 col16" >-0.01392</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col17" class="data row5 col17" >0.00698</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col18" class="data row5 col18" >-0.1085</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col19" class="data row5 col19" >0.006892</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col20" class="data row5 col20" >-0.1718</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col21" class="data row5 col21" >0.1282</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col22" class="data row5 col22" >0.2403</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col23" class="data row5 col23" >0.01427</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col24" class="data row5 col24" >0.03745</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row5_col25" class="data row5 col25" >-0.04195</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row6" class="row_heading level0 row6" >body-style</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col0" class="data row6 col0" >-0.5961</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col1" class="data row6 col1" >-0.2509</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col2" class="data row6 col2" >0.08949</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col3" class="data row6 col3" >-0.1479</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col4" class="data row6 col4" >0.06303</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col5" class="data row6 col5" >-0.6856</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col6" class="data row6 col6" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col7" class="data row6 col7" >-0.1557</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col8" class="data row6 col8" >-0.277</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col9" class="data row6 col9" >0.4014</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col10" class="data row6 col10" >0.3344</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col11" class="data row6 col11" >0.1317</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col12" class="data row6 col12" >0.5685</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col13" class="data row6 col13" >0.1285</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col14" class="data row6 col14" >-0.03702</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col15" class="data row6 col15" >-0.04841</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col16" class="data row6 col16" >-0.07335</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col17" class="data row6 col17" >-0.06508</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col18" class="data row6 col18" >0.01056</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col19" class="data row6 col19" >-0.01534</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col20" class="data row6 col20" >0.1362</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col21" class="data row6 col21" >-0.1524</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col22" class="data row6 col22" >-0.1094</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col23" class="data row6 col23" >0.0317</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col24" class="data row6 col24" >-0.00717</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row6_col25" class="data row6 col25" >-0.07268</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row7" class="row_heading level0 row7" >drive-wheels</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col0" class="data row7 col0" >-0.04167</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col1" class="data row7 col1" >0.311</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col2" class="data row7 col2" >-0.004317</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col3" class="data row7 col3" >-0.1323</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col4" class="data row7 col4" >0.06646</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col5" class="data row7 col5" >0.1049</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col6" class="data row7 col6" >-0.1557</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col7" class="data row7 col7" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col8" class="data row7 col8" >0.1479</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col9" class="data row7 col9" >0.4597</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col10" class="data row7 col10" >0.4856</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col11" class="data row7 col11" >0.4708</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col12" class="data row7 col12" >-0.01972</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col13" class="data row7 col13" >0.5751</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col14" class="data row7 col14" >-0.1168</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col15" class="data row7 col15" >0.2232</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col16" class="data row7 col16" >0.5243</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col17" class="data row7 col17" >0.4247</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col18" class="data row7 col18" >0.4818</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col19" class="data row7 col19" >0.07162</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col20" class="data row7 col20" >0.1275</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col21" class="data row7 col21" >0.5169</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col22" class="data row7 col22" >-0.03972</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col23" class="data row7 col23" >-0.4496</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col24" class="data row7 col24" >-0.4522</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row7_col25" class="data row7 col25" >0.5769</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row8" class="row_heading level0 row8" >engine-location</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col0" class="data row8 col0" >0.2125</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col1" class="data row8 col1" >4.281e-19</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col2" class="data row8 col2" >0.05461</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col3" class="data row8 col3" >0.04007</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col4" class="data row8 col4" >-0.05719</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col5" class="data row8 col5" >0.1391</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col6" class="data row8 col6" >-0.277</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col7" class="data row8 col7" >0.1479</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col8" class="data row8 col8" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col9" class="data row8 col9" >-0.1878</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col10" class="data row8 col10" >-0.05099</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col11" class="data row8 col11" >-0.0517</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col12" class="data row8 col12" >-0.1062</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col13" class="data row8 col13" >0.05047</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col14" class="data row8 col14" >0.1141</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col15" class="data row8 col15" >0.1355</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col16" class="data row8 col16" >0.1968</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col17" class="data row8 col17" >0.106</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col18" class="data row8 col18" >0.185</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col19" class="data row8 col19" >-0.1385</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col20" class="data row8 col20" >-0.01976</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col21" class="data row8 col21" >0.3176</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col22" class="data row8 col22" >0.1984</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col23" class="data row8 col23" >-0.1535</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col24" class="data row8 col24" >-0.102</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row8_col25" class="data row8 col25" >0.331</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row9" class="row_heading level0 row9" >wheel-base</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col0" class="data row9 col0" >-0.532</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col1" class="data row9 col1" >-0.05652</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col2" class="data row9 col2" >0.0785</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col3" class="data row9 col3" >-0.3083</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col4" class="data row9 col4" >0.2576</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col5" class="data row9 col5" >-0.4396</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col6" class="data row9 col6" >0.4014</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col7" class="data row9 col7" >0.4597</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col8" class="data row9 col8" >-0.1878</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col9" class="data row9 col9" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col10" class="data row9 col10" >0.8746</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col11" class="data row9 col11" >0.7951</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col12" class="data row9 col12" >0.5894</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col13" class="data row9 col13" >0.7764</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col14" class="data row9 col14" >-0.1356</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col15" class="data row9 col15" >-0.1846</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col16" class="data row9 col16" >0.5693</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col17" class="data row9 col17" >0.3846</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col18" class="data row9 col18" >0.4888</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col19" class="data row9 col19" >0.1609</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col20" class="data row9 col20" >0.2498</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col21" class="data row9 col21" >0.352</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col22" class="data row9 col22" >-0.3607</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col23" class="data row9 col23" >-0.4704</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col24" class="data row9 col24" >-0.5441</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row9_col25" class="data row9 col25" >0.5832</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row10" class="row_heading level0 row10" >length</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col0" class="data row10 col0" >-0.3576</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col1" class="data row10 col1" >0.01921</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col2" class="data row10 col2" >0.1196</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col3" class="data row10 col3" >-0.2127</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col4" class="data row10 col4" >0.2345</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col5" class="data row10 col5" >-0.3857</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col6" class="data row10 col6" >0.3344</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col7" class="data row10 col7" >0.4856</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col8" class="data row10 col8" >-0.05099</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col9" class="data row10 col9" >0.8746</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col10" class="data row10 col10" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col11" class="data row10 col11" >0.8411</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col12" class="data row10 col12" >0.491</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col13" class="data row10 col13" >0.8777</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col14" class="data row10 col14" >-0.1133</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col15" class="data row10 col15" >-0.1096</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col16" class="data row10 col16" >0.6834</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col17" class="data row10 col17" >0.5578</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col18" class="data row10 col18" >0.6065</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col19" class="data row10 col19" >0.1295</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col20" class="data row10 col20" >0.1584</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col21" class="data row10 col21" >0.5544</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col22" class="data row10 col22" >-0.287</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col23" class="data row10 col23" >-0.6709</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col24" class="data row10 col24" >-0.7047</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row10_col25" class="data row10 col25" >0.683</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row11" class="row_heading level0 row11" >width</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col0" class="data row11 col0" >-0.2329</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col1" class="data row11 col1" >0.08419</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col2" class="data row11 col2" >0.003783</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col3" class="data row11 col3" >-0.2339</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col4" class="data row11 col4" >0.3006</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col5" class="data row11 col5" >-0.1977</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col6" class="data row11 col6" >0.1317</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col7" class="data row11 col7" >0.4708</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col8" class="data row11 col8" >-0.0517</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col9" class="data row11 col9" >0.7951</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col10" class="data row11 col10" >0.8411</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col11" class="data row11 col11" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col12" class="data row11 col12" >0.2792</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col13" class="data row11 col13" >0.867</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col14" class="data row11 col14" >0.0123</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col15" class="data row11 col15" >-0.1941</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col16" class="data row11 col16" >0.7354</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col17" class="data row11 col17" >0.5214</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col18" class="data row11 col18" >0.5592</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col19" class="data row11 col19" >0.1829</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col20" class="data row11 col20" >0.1811</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col21" class="data row11 col21" >0.6422</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col22" class="data row11 col22" >-0.2199</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col23" class="data row11 col23" >-0.6427</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col24" class="data row11 col24" >-0.6772</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row11_col25" class="data row11 col25" >0.7287</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row12" class="row_heading level0 row12" >height</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col0" class="data row12 col0" >-0.541</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col1" class="data row12 col1" >-0.3707</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col2" class="data row12 col2" >0.2362</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col3" class="data row12 col3" >-0.2846</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col4" class="data row12 col4" >0.08731</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col5" class="data row12 col5" >-0.5403</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col6" class="data row12 col6" >0.5685</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col7" class="data row12 col7" >-0.01972</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col8" class="data row12 col8" >-0.1062</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col9" class="data row12 col9" >0.5894</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col10" class="data row12 col10" >0.491</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col11" class="data row12 col11" >0.2792</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col12" class="data row12 col12" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col13" class="data row12 col13" >0.2956</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col14" class="data row12 col14" >-0.127</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col15" class="data row12 col15" >-0.2838</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col16" class="data row12 col16" >0.06715</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col17" class="data row12 col17" >0.01705</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col18" class="data row12 col18" >0.1711</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col19" class="data row12 col19" >-0.05535</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col20" class="data row12 col20" >0.2612</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col21" class="data row12 col21" >-0.1101</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col22" class="data row12 col22" >-0.3206</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col23" class="data row12 col23" >-0.04864</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col24" class="data row12 col24" >-0.1074</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row12_col25" class="data row12 col25" >0.1344</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row13" class="row_heading level0 row13" >curb-weight</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col0" class="data row13 col0" >-0.2277</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col1" class="data row13 col1" >0.09779</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col2" class="data row13 col2" >0.02402</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col3" class="data row13 col3" >-0.2173</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col4" class="data row13 col4" >0.3249</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col5" class="data row13 col5" >-0.1907</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col6" class="data row13 col6" >0.1285</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col7" class="data row13 col7" >0.5751</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col8" class="data row13 col8" >0.05047</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col9" class="data row13 col9" >0.7764</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col10" class="data row13 col10" >0.8777</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col11" class="data row13 col11" >0.867</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col12" class="data row13 col12" >0.2956</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col13" class="data row13 col13" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col14" class="data row13 col14" >-0.05527</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col15" class="data row13 col15" >-0.04713</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col16" class="data row13 col16" >0.8506</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col17" class="data row13 col17" >0.6116</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col18" class="data row13 col18" >0.6485</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col19" class="data row13 col19" >0.1688</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col20" class="data row13 col20" >0.1514</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col21" class="data row13 col21" >0.751</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col22" class="data row13 col22" >-0.2663</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col23" class="data row13 col23" >-0.7574</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col24" class="data row13 col24" >-0.7975</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row13_col25" class="data row13 col25" >0.8208</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row14" class="row_heading level0 row14" >engine-type</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col0" class="data row14 col0" >0.05037</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col1" class="data row14 col1" >-0.0842</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col2" class="data row14 col2" >-0.05154</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col3" class="data row14 col3" >0.0827</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col4" class="data row14 col4" >-0.103</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col5" class="data row14 col5" >0.06265</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col6" class="data row14 col6" >-0.03702</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col7" class="data row14 col7" >-0.1168</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col8" class="data row14 col8" >0.1141</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col9" class="data row14 col9" >-0.1356</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col10" class="data row14 col10" >-0.1133</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col11" class="data row14 col11" >0.0123</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col12" class="data row14 col12" >-0.127</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col13" class="data row14 col13" >-0.05527</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col14" class="data row14 col14" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col15" class="data row14 col15" >0.2374</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col16" class="data row14 col16" >0.04077</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col17" class="data row14 col17" >-0.09179</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col18" class="data row14 col18" >0.0293</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col19" class="data row14 col19" >-0.1418</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col20" class="data row14 col20" >-0.07187</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col21" class="data row14 col21" >0.01026</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col22" class="data row14 col22" >0.005592</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col23" class="data row14 col23" >-0.085</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col24" class="data row14 col24" >-0.07846</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row14_col25" class="data row14 col25" >0.07154</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row15" class="row_heading level0 row15" >num-of-cylinders</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col0" class="data row15 col0" >0.1978</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col1" class="data row15 col1" >0.1668</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col2" class="data row15 col2" >-0.03994</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col3" class="data row15 col3" >0.1106</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col4" class="data row15 col4" >-0.1331</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col5" class="data row15 col5" >0.156</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col6" class="data row15 col6" >-0.04841</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col7" class="data row15 col7" >0.2232</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col8" class="data row15 col8" >0.1355</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col9" class="data row15 col9" >-0.1846</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col10" class="data row15 col10" >-0.1096</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col11" class="data row15 col11" >-0.1941</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col12" class="data row15 col12" >-0.2838</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col13" class="data row15 col13" >-0.04713</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col14" class="data row15 col14" >0.2374</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col15" class="data row15 col15" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col16" class="data row15 col16" >-0.08561</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col17" class="data row15 col17" >0.01197</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col18" class="data row15 col18" >-0.03293</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col19" class="data row15 col19" >-0.04996</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col20" class="data row15 col20" >-0.0647</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col21" class="data row15 col21" >0.1152</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col22" class="data row15 col22" >0.2227</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col23" class="data row15 col23" >-0.1264</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col24" class="data row15 col24" >-0.0859</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row15_col25" class="data row15 col25" >0.005384</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row16" class="row_heading level0 row16" >engine-size</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col0" class="data row16 col0" >-0.1058</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col1" class="data row16 col1" >0.111</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col2" class="data row16 col2" >-0.07092</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col3" class="data row16 col3" >-0.06959</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col4" class="data row16 col4" >0.1082</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col5" class="data row16 col5" >-0.01392</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col6" class="data row16 col6" >-0.07335</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col7" class="data row16 col7" >0.5243</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col8" class="data row16 col8" >0.1968</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col9" class="data row16 col9" >0.5693</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col10" class="data row16 col10" >0.6834</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col11" class="data row16 col11" >0.7354</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col12" class="data row16 col12" >0.06715</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col13" class="data row16 col13" >0.8506</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col14" class="data row16 col14" >0.04077</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col15" class="data row16 col15" >-0.08561</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col16" class="data row16 col16" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col17" class="data row16 col17" >0.5141</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col18" class="data row16 col18" >0.5838</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col19" class="data row16 col19" >0.2031</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col20" class="data row16 col20" >0.02897</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col21" class="data row16 col21" >0.8107</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col22" class="data row16 col22" >-0.2446</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col23" class="data row16 col23" >-0.6537</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col24" class="data row16 col24" >-0.6775</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row16_col25" class="data row16 col25" >0.8618</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row17" class="row_heading level0 row17" >fuel-system</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col0" class="data row17 col0" >0.09116</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col1" class="data row17 col1" >0.228</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col2" class="data row17 col2" >0.1466</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col3" class="data row17 col3" >0.04153</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col4" class="data row17 col4" >0.2881</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col5" class="data row17 col5" >0.00698</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col6" class="data row17 col6" >-0.06508</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col7" class="data row17 col7" >0.4247</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col8" class="data row17 col8" >0.106</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col9" class="data row17 col9" >0.3846</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col10" class="data row17 col10" >0.5578</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col11" class="data row17 col11" >0.5214</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col12" class="data row17 col12" >0.01705</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col13" class="data row17 col13" >0.6116</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col14" class="data row17 col14" >-0.09179</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col15" class="data row17 col15" >0.01197</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col16" class="data row17 col16" >0.5141</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col17" class="data row17 col17" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col18" class="data row17 col18" >0.4756</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col19" class="data row17 col19" >0.08815</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col20" class="data row17 col20" >-0.1008</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col21" class="data row17 col21" >0.6591</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col22" class="data row17 col22" >0.01471</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col23" class="data row17 col23" >-0.6716</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col24" class="data row17 col24" >-0.6457</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row17_col25" class="data row17 col25" >0.5165</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row18" class="row_heading level0 row18" >bore</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col0" class="data row18 col0" >-0.1301</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col1" class="data row18 col1" >-0.02927</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col2" class="data row18 col2" >0.2512</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col3" class="data row18 col3" >-0.05446</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col4" class="data row18 col4" >0.2126</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col5" class="data row18 col5" >-0.1085</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col6" class="data row18 col6" >0.01056</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col7" class="data row18 col7" >0.4818</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col8" class="data row18 col8" >0.185</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col9" class="data row18 col9" >0.4888</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col10" class="data row18 col10" >0.6065</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col11" class="data row18 col11" >0.5592</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col12" class="data row18 col12" >0.1711</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col13" class="data row18 col13" >0.6485</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col14" class="data row18 col14" >0.0293</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col15" class="data row18 col15" >-0.03293</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col16" class="data row18 col16" >0.5838</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col17" class="data row18 col17" >0.4756</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col18" class="data row18 col18" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col19" class="data row18 col19" >-0.05591</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col20" class="data row18 col20" >0.005201</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col21" class="data row18 col21" >0.5757</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col22" class="data row18 col22" >-0.2548</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col23" class="data row18 col23" >-0.5845</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col24" class="data row18 col24" >-0.587</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row18_col25" class="data row18 col25" >0.5323</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row19" class="row_heading level0 row19" >stroke</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col0" class="data row19 col0" >-0.008689</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col1" class="data row19 col1" >0.05493</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col2" class="data row19 col2" >-0.201</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col3" class="data row19 col3" >-0.2418</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col4" class="data row19 col4" >0.223</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col5" class="data row19 col5" >0.006892</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col6" class="data row19 col6" >-0.01534</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col7" class="data row19 col7" >0.07162</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col8" class="data row19 col8" >-0.1385</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col9" class="data row19 col9" >0.1609</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col10" class="data row19 col10" >0.1295</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col11" class="data row19 col11" >0.1829</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col12" class="data row19 col12" >-0.05535</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col13" class="data row19 col13" >0.1688</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col14" class="data row19 col14" >-0.1418</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col15" class="data row19 col15" >-0.04996</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col16" class="data row19 col16" >0.2031</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col17" class="data row19 col17" >0.08815</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col18" class="data row19 col18" >-0.05591</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col19" class="data row19 col19" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col20" class="data row19 col20" >0.1861</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col21" class="data row19 col21" >0.08826</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col22" class="data row19 col22" >-0.06684</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col23" class="data row19 col23" >-0.04218</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col24" class="data row19 col24" >-0.04396</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row19_col25" class="data row19 col25" >0.0821</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row20" class="row_heading level0 row20" >compression-ratio</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col0" class="data row20 col0" >-0.1785</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col1" class="data row20 col1" >-0.1145</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col2" class="data row20 col2" >0.1388</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col3" class="data row20 col3" >-0.9844</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col4" class="data row20 col4" >0.2955</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col5" class="data row20 col5" >-0.1718</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col6" class="data row20 col6" >0.1362</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col7" class="data row20 col7" >0.1275</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col8" class="data row20 col8" >-0.01976</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col9" class="data row20 col9" >0.2498</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col10" class="data row20 col10" >0.1584</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col11" class="data row20 col11" >0.1811</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col12" class="data row20 col12" >0.2612</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col13" class="data row20 col13" >0.1514</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col14" class="data row20 col14" >-0.07187</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col15" class="data row20 col15" >-0.0647</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col16" class="data row20 col16" >0.02897</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col17" class="data row20 col17" >-0.1008</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col18" class="data row20 col18" >0.005201</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col19" class="data row20 col19" >0.1861</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col20" class="data row20 col20" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col21" class="data row20 col21" >-0.2057</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col22" class="data row20 col22" >-0.4359</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col23" class="data row20 col23" >0.3247</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col24" class="data row20 col24" >0.2652</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row20_col25" class="data row20 col25" >0.07099</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row21" class="row_heading level0 row21" >horsepower</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col0" class="data row21 col0" >0.07139</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col1" class="data row21 col1" >0.2034</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col2" class="data row21 col2" >-0.05365</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col3" class="data row21 col3" >0.1652</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col4" class="data row21 col4" >0.2402</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col5" class="data row21 col5" >0.1282</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col6" class="data row21 col6" >-0.1524</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col7" class="data row21 col7" >0.5169</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col8" class="data row21 col8" >0.3176</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col9" class="data row21 col9" >0.352</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col10" class="data row21 col10" >0.5544</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col11" class="data row21 col11" >0.6422</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col12" class="data row21 col12" >-0.1101</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col13" class="data row21 col13" >0.751</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col14" class="data row21 col14" >0.01026</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col15" class="data row21 col15" >0.1152</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col16" class="data row21 col16" >0.8107</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col17" class="data row21 col17" >0.6591</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col18" class="data row21 col18" >0.5757</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col19" class="data row21 col19" >0.08826</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col20" class="data row21 col20" >-0.2057</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col21" class="data row21 col21" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col22" class="data row21 col22" >0.131</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col23" class="data row21 col23" >-0.8032</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col24" class="data row21 col24" >-0.7709</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row21_col25" class="data row21 col25" >0.7579</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row22" class="row_heading level0 row22" >peak-rpm</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col0" class="data row22 col0" >0.2737</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col1" class="data row22 col1" >0.2377</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col2" class="data row22 col2" >-0.2183</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col3" class="data row22 col3" >0.4771</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col4" class="data row22 col4" >-0.1836</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col5" class="data row22 col5" >0.2403</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col6" class="data row22 col6" >-0.1094</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col7" class="data row22 col7" >-0.03972</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col8" class="data row22 col8" >0.1984</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col9" class="data row22 col9" >-0.3607</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col10" class="data row22 col10" >-0.287</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col11" class="data row22 col11" >-0.2199</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col12" class="data row22 col12" >-0.3206</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col13" class="data row22 col13" >-0.2663</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col14" class="data row22 col14" >0.005592</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col15" class="data row22 col15" >0.2227</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col16" class="data row22 col16" >-0.2446</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col17" class="data row22 col17" >0.01471</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col18" class="data row22 col18" >-0.2548</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col19" class="data row22 col19" >-0.06684</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col20" class="data row22 col20" >-0.4359</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col21" class="data row22 col21" >0.131</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col22" class="data row22 col22" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col23" class="data row22 col23" >-0.1137</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col24" class="data row22 col24" >-0.05426</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row22_col25" class="data row22 col25" >-0.1009</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row23" class="row_heading level0 row23" >city-mpg</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col0" class="data row23 col0" >-0.03582</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col1" class="data row23 col1" >-0.2187</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col2" class="data row23 col2" >0.05364</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col3" class="data row23 col3" >-0.256</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col4" class="data row23 col4" >-0.2024</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col5" class="data row23 col5" >0.01427</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col6" class="data row23 col6" >0.0317</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col7" class="data row23 col7" >-0.4496</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col8" class="data row23 col8" >-0.1535</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col9" class="data row23 col9" >-0.4704</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col10" class="data row23 col10" >-0.6709</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col11" class="data row23 col11" >-0.6427</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col12" class="data row23 col12" >-0.04864</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col13" class="data row23 col13" >-0.7574</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col14" class="data row23 col14" >-0.085</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col15" class="data row23 col15" >-0.1264</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col16" class="data row23 col16" >-0.6537</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col17" class="data row23 col17" >-0.6716</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col18" class="data row23 col18" >-0.5845</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col19" class="data row23 col19" >-0.04218</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col20" class="data row23 col20" >0.3247</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col21" class="data row23 col21" >-0.8032</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col22" class="data row23 col22" >-0.1137</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col23" class="data row23 col23" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col24" class="data row23 col24" >0.9713</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row23_col25" class="data row23 col25" >-0.6674</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row24" class="row_heading level0 row24" >highway-mpg</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col0" class="data row24 col0" >0.03461</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col1" class="data row24 col1" >-0.1782</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col2" class="data row24 col2" >0.05002</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col3" class="data row24 col3" >-0.1914</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col4" class="data row24 col4" >-0.2544</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col5" class="data row24 col5" >0.03745</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col6" class="data row24 col6" >-0.00717</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col7" class="data row24 col7" >-0.4522</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col8" class="data row24 col8" >-0.102</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col9" class="data row24 col9" >-0.5441</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col10" class="data row24 col10" >-0.7047</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col11" class="data row24 col11" >-0.6772</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col12" class="data row24 col12" >-0.1074</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col13" class="data row24 col13" >-0.7975</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col14" class="data row24 col14" >-0.07846</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col15" class="data row24 col15" >-0.0859</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col16" class="data row24 col16" >-0.6775</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col17" class="data row24 col17" >-0.6457</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col18" class="data row24 col18" >-0.587</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col19" class="data row24 col19" >-0.04396</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col20" class="data row24 col20" >0.2652</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col21" class="data row24 col21" >-0.7709</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col22" class="data row24 col22" >-0.05426</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col23" class="data row24 col23" >0.9713</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col24" class="data row24 col24" >1</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row24_col25" class="data row24 col25" >-0.6905</td> 
    </tr>    <tr> 
        <th id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50level0_row25" class="row_heading level0 row25" >price</th> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col0" class="data row25 col0" >-0.0822</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col1" class="data row25 col1" >0.134</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col2" class="data row25 col2" >-0.1615</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col3" class="data row25 col3" >-0.1102</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col4" class="data row25 col4" >0.1773</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col5" class="data row25 col5" >-0.04195</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col6" class="data row25 col6" >-0.07268</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col7" class="data row25 col7" >0.5769</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col8" class="data row25 col8" >0.331</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col9" class="data row25 col9" >0.5832</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col10" class="data row25 col10" >0.683</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col11" class="data row25 col11" >0.7287</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col12" class="data row25 col12" >0.1344</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col13" class="data row25 col13" >0.8208</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col14" class="data row25 col14" >0.07154</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col15" class="data row25 col15" >0.005384</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col16" class="data row25 col16" >0.8618</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col17" class="data row25 col17" >0.5165</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col18" class="data row25 col18" >0.5323</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col19" class="data row25 col19" >0.0821</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col20" class="data row25 col20" >0.07099</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col21" class="data row25 col21" >0.7579</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col22" class="data row25 col22" >-0.1009</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col23" class="data row25 col23" >-0.6674</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col24" class="data row25 col24" >-0.6905</td> 
        <td id="T_38ab283a_e0fa_11e8_bee5_548ca0fcbf50row25_col25" class="data row25 col25" >1</td> 
    </tr></tbody> 
</table> 




```python
# Bloxplots
sns.jointplot(data=Auto1, x='price', y='engine-size', kind='reg', color='g')
plt.show()
```


![png](output_16_0.png)



```python
g = sns.lmplot('normalized-losses',"symboling", Auto1);
```


![png](output_17_0.png)



```python
g = sns.lmplot('price',"normalized-losses", Auto1);
```


![png](output_18_0.png)



```python
plt.rcParams['figure.figsize']=(10,5)
ax = sns.boxplot(x="drive-wheels", y="price", data=Auto1)
```


![png](output_19_0.png)



```python
plt.rcParams['figure.figsize']=(25,10)
ax = sns.boxplot(x="make", y="price", data=Auto1)
```


![png](output_20_0.png)



```python
from sklearn.preprocessing import Imputer
Auto1 = Auto1.replace('?', 'NaN')
imp = Imputer(missing_values='NaN', strategy='mean' )
Auto1[['normalized-losses','bore','stroke','horsepower','peak-rpm','price']] = imp.fit_transform(Auto1[['normalized-losses','bore','stroke','horsepower','peak-rpm','price']])
Auto1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>symboling</th>
      <th>normalized-losses</th>
      <th>make</th>
      <th>fuel-type</th>
      <th>aspiration</th>
      <th>num-of-doors</th>
      <th>body-style</th>
      <th>drive-wheels</th>
      <th>engine-location</th>
      <th>wheel-base</th>
      <th>...</th>
      <th>engine-size</th>
      <th>fuel-system</th>
      <th>bore</th>
      <th>stroke</th>
      <th>compression-ratio</th>
      <th>horsepower</th>
      <th>peak-rpm</th>
      <th>city-mpg</th>
      <th>highway-mpg</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3</td>
      <td>122.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>88.6</td>
      <td>...</td>
      <td>130</td>
      <td>5</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111.0</td>
      <td>5000.0</td>
      <td>21</td>
      <td>27</td>
      <td>13495.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>122.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>88.6</td>
      <td>...</td>
      <td>130</td>
      <td>5</td>
      <td>3.47</td>
      <td>2.68</td>
      <td>9.0</td>
      <td>111.0</td>
      <td>5000.0</td>
      <td>21</td>
      <td>27</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>122.0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>94.5</td>
      <td>...</td>
      <td>152</td>
      <td>5</td>
      <td>2.68</td>
      <td>3.47</td>
      <td>9.0</td>
      <td>154.0</td>
      <td>5000.0</td>
      <td>19</td>
      <td>26</td>
      <td>16500.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>164.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>0</td>
      <td>99.8</td>
      <td>...</td>
      <td>109</td>
      <td>5</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>10.0</td>
      <td>102.0</td>
      <td>5500.0</td>
      <td>24</td>
      <td>30</td>
      <td>13950.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2</td>
      <td>164.0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>99.4</td>
      <td>...</td>
      <td>136</td>
      <td>5</td>
      <td>3.19</td>
      <td>3.40</td>
      <td>8.0</td>
      <td>115.0</td>
      <td>5500.0</td>
      <td>18</td>
      <td>22</td>
      <td>17450.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 26 columns</p>
</div>




```python
# Spliting the data into train and test dataset in 80% and 20% respectively

import sklearn
from sklearn import model_selection
Y = Auto1['price']
X = Auto1.drop('price',axis =1)

x_train, x_test, y_train,  y_test = sklearn.model_selection.train_test_split(X, Y,train_size=0.8, test_size=0.2, random_state=0)
```


```python
from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
lm_1 = regressor.fit(x_train, y_train)
```


```python
lm_1.score(x_train,y_train)
```




    0.9123334982164664




```python
lm_1.score(x_test,y_test)
```




    0.6884334242207176




```python
Auto1 = Auto1.copy()
names = []
for name in Auto1.columns:
    names.append(name.replace('-', '_'))

Auto1.columns = names
```


```python
import statsmodels.formula.api as smf

lm0 = smf.ols(formula= 'price ~ symboling + normalized_losses + wheel_base +  width + height + length + + curb_weight + engine_size + stroke + compression_ratio + peak_rpm + city_mpg + highway_mpg + bore + horsepower' , data =Auto1).fit()

# 
print(lm0.summary())
```

                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                  price   R-squared:                       0.814
    Model:                            OLS   Adj. R-squared:                  0.799
    Method:                 Least Squares   F-statistic:                     55.03
    Date:                Mon, 05 Nov 2018   Prob (F-statistic):           1.38e-60
    Time:                        18:26:38   Log-Likelihood:                -1957.1
    No. Observations:                 205   AIC:                             3946.
    Df Residuals:                     189   BIC:                             3999.
    Df Model:                          15                                         
    Covariance Type:            nonrobust                                         
    =====================================================================================
                            coef    std err          t      P>|t|      [0.025      0.975]
    -------------------------------------------------------------------------------------
    Intercept         -3.105e+04   1.75e+04     -1.773      0.078   -6.56e+04    3489.215
    symboling           491.7514    297.043      1.655      0.099     -94.193    1077.696
    normalized_losses    -4.4345     10.001     -0.443      0.658     -24.163      15.294
    wheel_base          195.0408    122.400      1.593      0.113     -46.405     436.487
    width                73.1035    276.371      0.265      0.792    -472.065     618.272
    height              119.9127    161.556      0.742      0.459    -198.773     438.598
    length              -43.9191     61.417     -0.715      0.475    -165.070      77.231
    curb_weight           1.9823      1.933      1.026      0.306      -1.830       5.795
    engine_size         134.5349     15.367      8.755      0.000     104.222     164.848
    stroke            -3062.3169    862.044     -3.552      0.000   -4762.781   -1361.853
    compression_ratio   274.2731     92.429      2.967      0.003      91.948     456.598
    peak_rpm              2.7758      0.752      3.689      0.000       1.292       4.260
    city_mpg           -147.4286    200.813     -0.734      0.464    -543.552     248.695
    highway_mpg           5.7985    178.490      0.032      0.974    -346.290     357.887
    bore              -1273.1774   1339.435     -0.951      0.343   -3915.340    1368.985
    horsepower            1.0244     18.319      0.056      0.955     -35.112      37.161
    ==============================================================================
    Omnibus:                       24.998   Durbin-Watson:                   1.111
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):              101.787
    Skew:                           0.293   Prob(JB):                     7.89e-23
    Kurtosis:                       6.402   Cond. No.                     4.09e+05
    ==============================================================================
    
    Warnings:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
    [2] The condition number is large, 4.09e+05. This might indicate that there are
    strong multicollinearity or other numerical problems.
    


```python
import pandas
from pandas.plotting import scatter_matrix
import matplotlib.pyplot as plt
from sklearn import model_selection
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
```


```python
# Split-out validation dataset
array = Auto1.values
X = array[:,0:4]
Y = array[:,4]
validation_size = 0.20
seed = 7
X_train, X_validation, Y_train, Y_validation = model_selection.train_test_split(X, Y, test_size=validation_size, random_state=seed)
seed = 7
scoring = 'accuracy'
```


```python
models = []
models.append(('LR', LogisticRegression()))
models.append(('LDA', LinearDiscriminantAnalysis()))
models.append(('KNN', KNeighborsClassifier()))
models.append(('CART', DecisionTreeClassifier()))
models.append(('NB', GaussianNB()))
models.append(('SVM', SVC()))

# evaluate each model in turn
results = []
names = []
for name, model in models:
    kfold = model_selection.KFold(n_splits=10, random_state=seed)
    cv_results = model_selection.cross_val_score(model, X_train, Y_train, cv=kfold, scoring=scoring)
    results.append(cv_results)
    names.append(name)
    msg = "%s: %f (%f)" % (name, cv_results.mean(), cv_results.std())
    print(msg)
```

    LR: 0.835294 (0.061822)
    LDA: 0.853676 (0.063184)
    KNN: 0.822426 (0.071480)
    CART: 0.841176 (0.063205)
    NB: 0.853676 (0.063184)
    SVM: 0.805147 (0.075614)
    


```python
# Compare Algorithms
fig = plt.figure()
fig.suptitle('Algorithm Comparison')
ax = fig.add_subplot(111)
plt.boxplot(results)
ax.set_xticklabels(names)
plt.show()
```


![png](output_31_0.png)



```python
# Make predictions on validation dataset 
LDA = LinearDiscriminantAnalysis()
LDA.fit(X_train, Y_train)
predictions = LDA.predict(X_validation)
print(accuracy_score(Y_validation, predictions))
print(confusion_matrix(Y_validation, predictions))
print(classification_report(Y_validation, predictions))
```

    0.8292682926829268
    [[32  3]
     [ 4  2]]
                 precision    recall  f1-score   support
    
            0.0       0.89      0.91      0.90        35
            1.0       0.40      0.33      0.36         6
    
    avg / total       0.82      0.83      0.82        41
    
    


```python
NB = GaussianNB()
NB.fit(X_train, Y_train)
predictions = NB.predict(X_validation)
print(accuracy_score(Y_validation, predictions))
print(confusion_matrix(Y_validation, predictions))
print(classification_report(Y_validation, predictions))
```

    0.8292682926829268
    [[32  3]
     [ 4  2]]
                 precision    recall  f1-score   support
    
            0.0       0.89      0.91      0.90        35
            1.0       0.40      0.33      0.36         6
    
    avg / total       0.82      0.83      0.82        41
    
    


```python
CART = DecisionTreeClassifier()
CART.fit(X_train, Y_train)
predictions = CART.predict(X_validation)
print(accuracy_score(Y_validation, predictions))
print(confusion_matrix(Y_validation, predictions))
print(classification_report(Y_validation, predictions))
```

    0.8536585365853658
    [[33  2]
     [ 4  2]]
                 precision    recall  f1-score   support
    
            0.0       0.89      0.94      0.92        35
            1.0       0.50      0.33      0.40         6
    
    avg / total       0.83      0.85      0.84        41
    
    


```python
# Thank you
```
